function loadCategories() {
    var container = document.getElementById("categoryContainer");
    if (!container) return;

    xhrGet("https://8store.dankassassin368.com/api/metadata/categories", function (err, data) {
        if (err) return;

        var appCats = (data && data.app_categories && data.app_categories.slice) ? data.app_categories : [];
        var gameCats = (data && data.game_categories && data.game_categories.slice) ? data.game_categories : [];
        var categories = appCats.concat(gameCats);

        container.innerHTML = "";

        for (var i = 0; i < categories.length; i++) {
            var cat = categories[i];
            var slug = slugifyCategory(cat);

            var li = document.createElement("li");
            li.className = "nav-item";

            li.innerHTML =
                '<a href="#" class="nav-link" data-filter="' + slug + '">' +
                    '<i class="fas fa-tag nav-icon"></i>' +
                    '<span>' + cat + '</span>' +
                '</a>';

            container.appendChild(li);
        }
    });
}
