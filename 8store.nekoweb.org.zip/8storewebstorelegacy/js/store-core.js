function slugifyCategory(name) {
    if (!name) return "";
    return String(name)
        .toLowerCase()
        .replace(/\s*\+\s*/g, "-")
        .replace(/\s+/g, "-");
}

function xhrGet(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.setRequestHeader("Accept", "application/json");

    xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;

        if (xhr.status >= 200 && xhr.status < 300) {
            var data = null;
            try {
                data = JSON.parse(xhr.responseText);
            } catch (e) {
                callback(e, null);
                return;
            }
            callback(null, data);
        } else {
            callback(new Error("XHR failed: " + xhr.status), null);
        }
    };

    xhr.send();
}

function normalizeApp(raw) {
    var app = {};

    app.id = raw.id || "";
    app.name = raw.name || "Unknown App";
    app.publisher = raw.publisher || "Unknown Publisher";

    if (!raw.description || raw.description.trim() === "") {
        app.description = "No description available.";
    } else {
        app.description = raw.description;
    }

    app.category = raw.category || "Uncategorized";
    app.categorySlug = slugifyCategory(app.category);

    app.type = raw.type || "App";
    app.typeLower = app.type.toLowerCase();

    app.version = raw.version || "";
    app.featured = raw.featured === 1 || raw.featured === "1";

    app.iconUrl = raw.iconUrl || "";
    app.downloadUrl = raw.downloadUrl || "";

    app.screenshot1 = raw.screenshot1 || "";
    app.screenshot2 = raw.screenshot2 || "";
    app.screenshot3 = raw.screenshot3 || "";

    return app;
}
