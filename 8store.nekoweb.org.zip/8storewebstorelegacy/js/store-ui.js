(function () {

    function findAppById(id) {
        var apps = window._allApps || [];
        for (var i = 0; i < apps.length; i++) {
            if (apps[i].id === id) return apps[i];
        }
        return null;
    }

    function showMainList() {
        var main = document.getElementById("mainContent");
        var detail = document.getElementById("appDetailPage");
        if (main) main.style.display = "";
        if (detail) {
            detail.style.display = "none";
            detail.innerHTML = "";
        }
    }

    function showAppDetail(app) {
        var main = document.getElementById("mainContent");
        var detail = document.getElementById("appDetailPage");

        if (main) main.style.display = "none";
        if (!detail) return;
        detail.style.display = "block";

        var html = '';

        html += '<div class="detail-header">';

        html += '<a href="#" id="detailBackBtn" class="back-btn" style="margin-right:20px; display:flex; align-items:center; color:white; text-decoration:none; font-size:18px;">';
        html += '<i class="fas fa-arrow-left" style="margin-right:8px;"></i> Back';
        html += '</a>';

        html += '  <div class="detail-icon">';
        html += '    <img src="' + app.iconUrl + '" alt="' + app.name + '" onerror="this.onerror=null; this.src=\'https://cdn-icons-png.flaticon.com/512/888/888879.png\'">';
        html += '  </div>';
        html += '  <div class="detail-header-info">';
        html += '    <h1 class="detail-title">' + app.name + '</h1>';
        html += '    <div class="detail-publisher">' + app.publisher + '</div>';
        html += '    <div class="detail-version">VERSION ' + app.version + '</div>';
        html += '    <button class="detail-download-btn" data-app-id="' + app.id + '"><i class="fas fa-download"></i> DOWNLOAD NOW</button>';
        html += '  </div>';
        html += '</div>';

        html += '<div class="detail-content">';

        html += '<div class="detail-left-column">';
        html += '  <div class="detail-section">';
        html += '    <h3>DESCRIPTION</h3>';
        html += '    <p>' + app.description + '</p>';
        html += '  </div>';

        html += '  <div class="detail-section">';
        html += '    <h3>SCREENSHOTS</h3>';
        html += '    <div class="screenshots">';
        if (app.screenshot1) html += '      <div class="screenshot"><img src="' + app.screenshot1 + '"></div>';
        if (app.screenshot2) html += '      <div class="screenshot"><img src="' + app.screenshot2 + '"></div>';
        if (app.screenshot3) html += '      <div class="screenshot"><img src="' + app.screenshot3 + '"></div>';
        html += '    </div>';
        html += '  </div>';
        html += '</div>';

        html += '<div class="detail-right-column">';
        html += '  <div class="detail-section">';
        html += '    <h3>APP DETAILS</h3>';
        html += '    <ul class="detail-info-list">';
        html += '      <li><span class="label">NAME</span><span class="value">' + app.name + '</span></li>';
        html += '      <li><span class="label">PUBLISHER</span><span class="value">' + app.publisher + '</span></li>';
        html += '      <li><span class="label">VERSION</span><span class="value">' + app.version + '</span></li>';
        html += '      <li><span class="label">STATUS</span><span class="value">STANDARD APP</span></li>';
        html += '      <li><span class="label">APP ID</span><span class="value">' + app.id + '</span></li>';
        html += '    </ul>';
        html += '  </div>';

        html += '  <div class="detail-section">';
        html += '    <h3>SYSTEM REQUIREMENTS</h3>';
        html += '    <p>WINDOWS 8.1 OR LATER REQUIRED</p>';
        html += '  </div>';
        html += '</div>';

        html += '</div>';

        detail.innerHTML = html;
    }

    function applyFilter(filter) {
        var apps = window._allApps || [];
        var filtered = [];
        var i;

        if (filter === "all") {
            filtered = apps.slice(0);
        } else if (filter === "featured") {
            for (i = 0; i < apps.length; i++) if (apps[i].featured) filtered.push(apps[i]);
        } else if (filter === "az") {
            filtered = apps.slice(0);
            filtered.sort(function (a, b) {
                var an = a.name.toLowerCase();
                var bn = b.name.toLowerCase();
                if (an < bn) return -1;
                if (an > bn) return 1;
                return 0;
            });
        } else if (filter === "type-game") {
            for (i = 0; i < apps.length; i++) if (apps[i].typeLower === "game") filtered.push(apps[i]);
        } else if (filter === "type-app") {
            for (i = 0; i < apps.length; i++) if (apps[i].typeLower === "app") filtered.push(apps[i]);
        } else {
            for (i = 0; i < apps.length; i++) if (apps[i].categorySlug === filter) filtered.push(apps[i]);
        }

        renderApps(filtered);

        var title = document.getElementById("sectionTitle");
        if (title) {
            if (filter === "all") title.innerHTML = "ALL APPS";
            else if (filter === "featured") title.innerHTML = "FEATURED";
            else if (filter === "az") title.innerHTML = "A-Z";
            else if (filter === "type-game") title.innerHTML = "ALL GAMES";
            else if (filter === "type-app") title.innerHTML = "ALL APPS";
            else title.innerHTML = filter.toUpperCase();
        }
    }

    function applySearch(query) {
        var apps = window._allApps || [];
        var q = String(query || "").toLowerCase();
        var filtered = [];

        if (!q) {
            renderApps(apps);
            return;
        }

        for (var i = 0; i < apps.length; i++) {
            var app = apps[i];
            var hay = (app.name + " " + app.description + " " + app.publisher + " " + app.category).toLowerCase();
            if (hay.indexOf(q) !== -1) filtered.push(app);
        }

        renderApps(filtered);
    }

    document.addEventListener("DOMContentLoaded", function () {
        var sidebar = document.querySelector(".sidebar");
        var appList = document.getElementById("appList");
        var searchBox = document.getElementById("searchBox");
        var backBtn = document.getElementById("backBtn");

        loadCategories();
        loadApps(function (apps) {
            renderApps(apps);
        });

        if (sidebar) {
            sidebar.addEventListener("click", function (e) {
                var t = e.target;

                while (t && t.nodeType !== 1) t = t.parentNode;
                while (t && t !== sidebar && !t.getAttribute("data-filter")) {
                    t = t.parentNode;
                }
                if (!t || t === sidebar) return;

                e.preventDefault();

                var links = sidebar.querySelectorAll(".nav-link");
                for (var i = 0; i < links.length; i++) {
                    links[i].className = links[i].className.replace(" active", "");
                }
                if (t.className.indexOf("active") === -1) {
                    t.className += " active";
                }

                showMainList();
                applyFilter(t.getAttribute("data-filter"));
            });
        }

        if (appList) {
            appList.addEventListener("click", function (e) {
                var t = e.target;

                while (t && t.nodeType !== 1) t = t.parentNode;
                while (t && t !== appList && !t.getAttribute("data-app-id")) {
                    t = t.parentNode;
                }
                if (!t || t === appList) return;

                var appId = t.getAttribute("data-app-id");
                var app = findAppById(appId);
                if (app) showAppDetail(app);
            });
        }

        document.body.addEventListener("click", function (e) {
            var t = e.target;

            while (t && t.nodeType !== 1) t = t.parentNode;
            if (!t || !t.className) return;

            if (t.id === "detailBackBtn") {
                e.preventDefault();
                showMainList();
                return;
            }

            if (t.className.indexOf("download-btn") !== -1 ||
                t.className.indexOf("detail-download-btn") !== -1) {

                var appId = t.getAttribute("data-app-id");
                var app = findAppById(appId);
                if (app && app.downloadUrl) {
                    e.preventDefault();
                    e.stopPropagation();
                    window.location.href = app.downloadUrl;
                }
            }
        });

        if (searchBox) {
            searchBox.addEventListener("keyup", function () {
                applySearch(searchBox.value);
            });
        }

        if (backBtn) {
            backBtn.addEventListener("click", function (e) {
                e.preventDefault();
                showMainList();
            });
        }
    });

})();
