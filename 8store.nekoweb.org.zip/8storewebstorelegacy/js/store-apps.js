window._allApps = [];

function loadApps(callback) {
    xhrGet("https://8store.dankassassin368.com/api/legacy/applications", function (err, data) {
        if (err) {
            callback([]);
            return;
        }

        var rawApps = (data && data.slice) ? data : [];
        var apps = [];

        for (var i = 0; i < rawApps.length; i++) {
            apps.push(normalizeApp(rawApps[i]));
        }

        window._allApps = apps;
        callback(apps);
    });
}

function renderApps(apps) {
    var list = document.getElementById("appList");
    if (!list) return;

    list.innerHTML = "";

    for (var i = 0; i < apps.length; i++) {
        var app = apps[i];

        var html = '';

        html += '<div class="app-item" data-app-id="' + app.id + '">';

        html += '<div class="app-icon-container">';
        html += '<img src="' + app.iconUrl + '" alt="' + app.name + '" onerror="this.onerror=null; this.src=\'https://8store.nekoweb.org/8storewebstore.dankassassin368.com/img/placeholder.png\'">';
        html += '</div>';

        html += '<div class="app-info-container">';
        html += '<h3 class="app-title">' + app.name + '</h3>';
        html += '<div class="app-publisher">' + app.publisher + '</div>';
        html += '<p class="app-description">' + app.description + '</p>';

        html += '<div class="app-meta">';
        html += '<span class="meta-badge category">' + app.category + '</span>';
        html += '<span class="meta-badge type">' + app.type + '</span>';
        html += '</div>';

        html += '<div class="app-footer">';
        html += '<div class="app-version">VERSION ' + app.version + '</div>';
        html += '<button class="download-btn" data-app-id="' + app.id + '">';
        html += '<i class="fas fa-download"></i> DOWNLOAD';
        html += '</button>';
        html += '</div>';

        html += '</div>';
        html += '</div>';

        var wrapper = document.createElement("div");
        wrapper.innerHTML = html;
        list.appendChild(wrapper.firstChild);
    }
}
