<?php
// Configuration
define('JSON_DIR', 'data/');
define('APPS_FILE', JSON_DIR . 'apps.json');
define('PENDING_FILE', JSON_DIR . 'pending.json');

// Create data directory if it doesn't exist
if (!file_exists(JSON_DIR)) {
    mkdir(JSON_DIR, 0755, true);
}

// Create empty files if they don't exist
if (!file_exists(APPS_FILE)) {
    file_put_contents(APPS_FILE, '[]');
}

if (!file_exists(PENDING_FILE)) {
    file_put_contents(PENDING_FILE, '[]');
}

header('Content-Type: application/json');

// Get POST data
$name = $_POST['name'] ?? '';
$publisher = $_POST['publisher'] ?? '';
$version = $_POST['version'] ?? '';
$description = $_POST['description'] ?? '';
$downloadUrl = $_POST['downloadUrl'] ?? '';
$iconUrl = $_POST['iconUrl'] ?? 'https://icons.iconarchive.com/icons/dakirby309/windows-8-metro/256/Folders-OS-Windows-8-Metro-icon.png';

// Validate required fields
if (empty($name) || empty($publisher) || empty($version) || empty($downloadUrl)) {
    echo json_encode(['success' => false, 'message' => 'All required fields must be filled']);
    exit;
}

// Function to check if URL is from disallowed domain
function isDisallowedDomain($url) {
    $disallowedDomains = [
        'mediafire.com',
        'www.mediafire.com',
        'mediafire',
        'archive.org',
        'www.archive.org',
        'archive',
        'catbox.moe',
        'www.catbox.moe',
        'catbox'
    ];
    
    $urlLower = strtolower($url);
    
    // Check if URL contains any disallowed domain
    foreach ($disallowedDomains as $domain) {
        if (strpos($urlLower, $domain) !== false) {
            return true;
        }
    }
    
    return false;
}

// Check for disallowed domains
if (isDisallowedDomain($downloadUrl)) {
    // Identify which domain was matched for better error message
    $urlLower = strtolower($downloadUrl);
    $blockedDomain = '';
    
    if (strpos($urlLower, 'mediafire') !== false) {
        $blockedDomain = 'MediaFire';
    } elseif (strpos($urlLower, 'archive.org') !== false) {
        $blockedDomain = 'Archive.org';
    } elseif (strpos($urlLower, 'sendspace') !== false) {
        $blockedDomain = 'sendspace.com';
    } elseif (strpos($urlLower, 'catbox') !== false) {
        $blockedDomain = 'Catbox.moe';
    } else {
        $blockedDomain = 'a restricted file hosting service';
    }
    
    echo json_encode(['success' => false, 'message' => $blockedDomain . ' links are not allowed. Please use direct .appx/.appxbundle download links.']);
    exit;
}

// Validate URL format
if (!filter_var($downloadUrl, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid URL format']);
    exit;
}

// Validate URL ends with .appx or .appxbundle
if (!preg_match('/\.appx(bundle)?$/i', $downloadUrl)) {
    echo json_encode(['success' => false, 'message' => 'Download URL must end with .appx or .appxbundle']);
    exit;
}

// Read pending submissions
$pendingData = file_get_contents(PENDING_FILE);
$pending = json_decode($pendingData, true);

if ($pending === null) {
    $pending = [];
}

// Generate temporary ID (timestamp-based)
$tempId = 'P' . time() . rand(100, 999);

// Create submission object
$submission = [
    'tempId' => $tempId,
    'name' => $name,
    'publisher' => $publisher,
    'version' => $version,
    'description' => $description,
    'downloadUrl' => $downloadUrl,
    'iconUrl' => $iconUrl,
    'submitted_at' => date('Y-m-d H:i:s'),
    'status' => 'pending'
];

// Add to pending submissions
$pending[] = $submission;

// Save pending submissions
if (file_put_contents(PENDING_FILE, json_encode($pending, JSON_PRETTY_PRINT)) === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to save submission']);
    exit;
}

// Return success response
echo json_encode([
    'success' => true,
    'message' => 'App submitted for review',
    'tempId' => $tempId
]);
?>