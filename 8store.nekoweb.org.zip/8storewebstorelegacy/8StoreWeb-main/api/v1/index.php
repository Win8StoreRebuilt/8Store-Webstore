<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Set headers FIRST
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if allow_url_fopen is enabled
if (!ini_get('allow_url_fopen')) {
    echo json_encode([
        'success' => false,
        'error' => 'Server configuration error: allow_url_fopen is disabled.'
    ]);
    exit();
}

// Get and parse input
$input = file_get_contents('php://input');
if (empty($input)) {
    echo json_encode(['success' => false, 'error' => 'No data received']);
    exit();
}

$data = json_decode($input, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON: ' . json_last_error_msg()]);
    exit();
}

// Validate action
if (!isset($data['action'])) {
    echo json_encode(['success' => false, 'error' => 'Action parameter is required']);
    exit();
}

$action = $data['action'];
$requestData = $data['data'] ?? [];

// Include required files
require_once 'config.php';
require_once 'SupabaseClient.php';

$supabase = new SupabaseClient();

try {
    switch ($action) {
        case 'signup':
            handleSignup($supabase, $requestData);
            break;
            
        case 'signin':
            handleSignin($supabase, $requestData);
            break;
            
        case 'signout':
            handleSignout($requestData);
            break;
            
        case 'get-reviews':
            handleGetReviews($supabase, $requestData);
            break;
            
        case 'submit-review':
            handleSubmitReview($supabase, $requestData);
            break;
            
        case 'delete-review':
            handleDeleteReview($supabase, $requestData);
            break;
            
        case 'get-user-reviews':
            handleGetUserReviews($supabase, $requestData);
            break;
            
        case 'get-review':
            handleGetReview($supabase, $requestData);
            break;
            
        case 'validate-token':
            handleValidateToken($supabase, $requestData);
            break;
            
        case 'test':
            echo json_encode([
                'success' => true,
                'message' => 'API is working',
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            break;
            
        case 'test-reviews':
            handleTestReviews($supabase, $requestData);
            break;
            
        case 'get-all-apps-review-stats':
            handleGetAllAppsReviewStats($supabase, $requestData);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action: ' . $action]);
    }
} catch (Exception $e) {
    error_log("API Exception: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}

// ========== HANDLER FUNCTIONS ==========

function handleTestReviews($supabase, $data) {
    try {
        // Get sample reviews to see what's in the database
        $response = $supabase->request('GET', 
            '/rest/v1/reviews?select=*&limit=10', 
            null, 
            null
        );
        
        error_log("Test reviews response - Success: " . ($response['success'] ? 'true' : 'false'));
        
        if ($response['success'] && is_array($response['data'])) {
            error_log("Found " . count($response['data']) . " reviews in database");
            foreach ($response['data'] as $index => $review) {
                error_log("Review " . $index . ": app_id=" . ($review['app_id'] ?? 'null') . 
                         ", rating=" . ($review['rating'] ?? 'null'));
            }
        }
        
        echo json_encode([
            'success' => $response['success'],
            'data' => $response['data'],
            'count' => is_array($response['data']) ? count($response['data']) : 0
        ]);
    } catch (Exception $e) {
        error_log("Test reviews error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function handleGetAllAppsReviewStats($supabase, $data) {
    try {
        error_log("=== Starting get-all-apps-review-stats ===");
        
        // Get ALL reviews from Supabase
        $response = $supabase->request('GET', 
            '/rest/v1/reviews?select=app_id,rating&order=app_id', 
            null, 
            null
        );
        
        error_log("Supabase response success: " . ($response['success'] ? 'true' : 'false'));
        error_log("Response code: " . ($response['code'] ?? 'N/A'));
        
        if ($response['success'] && is_array($response['data'])) {
            error_log("Found " . count($response['data']) . " reviews total");
            
            if (count($response['data']) === 0) {
                error_log("WARNING: No reviews found in database!");
            } else {
                // Log first few reviews to see what we have
                for ($i = 0; $i < min(3, count($response['data'])); $i++) {
                    $review = $response['data'][$i];
                    error_log("Sample review " . $i . ": app_id='" . ($review['app_id'] ?? 'null') . 
                             "', rating=" . ($review['rating'] ?? 'null'));
                }
            }
            
            // Group reviews by app_id and calculate stats
            $statsByApp = [];
            
            foreach ($response['data'] as $review) {
                $appId = $review['app_id'] ?? '';
                $rating = intval($review['rating'] ?? 0);
                
                // Clean up app ID
                $appId = trim($appId);
                
                if (!empty($appId) && $rating > 0 && $rating <= 5) {
                    if (!isset($statsByApp[$appId])) {
                        $statsByApp[$appId] = ['total' => 0, 'count' => 0];
                    }
                    $statsByApp[$appId]['total'] += $rating;
                    $statsByApp[$appId]['count']++;
                }
            }
            
            error_log("Processed reviews for " . count($statsByApp) . " unique apps");
            
            // Convert to response format
            $statsResponse = [];
            foreach ($statsByApp as $appId => $data) {
                if ($data['count'] > 0) {
                    $average = round($data['total'] / $data['count'], 2);
                    $statsResponse[] = [
                        'app_id' => $appId,
                        'average_rating' => $average,
                        'review_count' => $data['count']
                    ];
                }
            }
            
            // Sort by app_id for consistency
            usort($statsResponse, function($a, $b) {
                return strcmp($a['app_id'], $b['app_id']);
            });
            
            error_log("Returning stats for " . count($statsResponse) . " apps with valid reviews");
            
            if (count($statsResponse) > 0) {
                for ($i = 0; $i < min(3, count($statsResponse)); $i++) {
                    $stat = $statsResponse[$i];
                    error_log("Sample stat " . $i . ": app_id='" . $stat['app_id'] . 
                             "', avg=" . $stat['average_rating'] . ", count=" . $stat['review_count']);
                }
            }
            
            echo json_encode([
                'success' => true,
                'stats' => $statsResponse,
                'total_apps_with_reviews' => count($statsResponse),
                'debug' => [
                    'total_reviews_processed' => count($response['data']),
                    'unique_apps_found' => count($statsByApp),
                    'apps_with_valid_reviews' => count($statsResponse)
                ]
            ]);
        } else {
            error_log("ERROR: Supabase request failed or returned no data");
            if (isset($response['data'])) {
                error_log("Error data: " . json_encode($response['data']));
            }
            
            // Return empty but successful response
            echo json_encode([
                'success' => true,
                'stats' => [],
                'total_apps_with_reviews' => 0,
                'debug' => [
                    'error' => 'No reviews found or database error'
                ]
            ]);
        }
        
        error_log("=== Finished get-all-apps-review-stats ===");
        
    } catch (Exception $e) {
        error_log("Get all apps review stats error: " . $e->getMessage());
        error_log("Stack trace: " . $e->getTraceAsString());
        echo json_encode([
            'success' => false,
            'error' => 'Failed to get review stats: ' . $e->getMessage(),
            'stats' => [],
            'total_apps_with_reviews' => 0
        ]);
    }
}

function handleSignup($supabase, $data) {
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    $username = $data['username'] ?? '';
    
    if (empty($email) || empty($password) || empty($username)) {
        echo json_encode(['success' => false, 'error' => 'Email, password and username are required']);
        exit();
    }
    
    $response = $supabase->signUp($email, $password, $username);
    
    if ($response['success']) {
        $userData = $response['data']['user'] ?? [];
        $sessionData = $response['data']['session'] ?? [];
        
        echo json_encode([
            'success' => true,
            'user' => [
                'id' => $userData['id'] ?? '',
                'email' => $userData['email'] ?? $email,
                'username' => $username
            ],
            'session' => [
                'access_token' => $sessionData['access_token'] ?? null,
                'refresh_token' => $sessionData['refresh_token'] ?? null
            ]
        ]);
    } else {
        $error = 'Signup failed';
        if (isset($response['data']['error_description'])) {
            $error = $response['data']['error_description'];
        } elseif (isset($response['data']['message'])) {
            $error = $response['data']['message'];
        }
        
        // Check for specific errors
        if (strpos(strtolower($error), 'already registered') !== false) {
            $error = 'This email is already registered. Please try logging in.';
        }
        
        echo json_encode(['success' => false, 'error' => $error]);
    }
}

function handleSignin($supabase, $data) {
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Email and password are required']);
        exit();
    }
    
    $response = $supabase->signIn($email, $password);
    
    if ($response['success']) {
        $userData = $response['data']['user'] ?? [];
        $sessionData = $response['data'] ?? []; // Note: signin returns at root
        
        echo json_encode([
            'success' => true,
            'user' => [
                'id' => $userData['id'] ?? '',
                'email' => $userData['email'] ?? $email,
                'username' => $userData['user_metadata']['username'] ?? explode('@', $email)[0]
            ],
            'session' => [
                'access_token' => $sessionData['access_token'] ?? null,
                'refresh_token' => $sessionData['refresh_token'] ?? null
            ]
        ]);
    } else {
        $error = 'Login failed';
        if (isset($response['data']['error_description'])) {
            $error = $response['data']['error_description'];
        }
        
        // Handle specific errors
        $lowerError = strtolower($error);
        if (strpos($lowerError, 'invalid login credentials') !== false) {
            $error = 'Invalid email or password';
        } elseif (strpos($lowerError, 'email not confirmed') !== false) {
            $error = 'Please confirm your email before logging in';
        }
        
        echo json_encode(['success' => false, 'error' => $error]);
    }
}

function handleSignout($data) {
    // With JWT, signout is client-side
    echo json_encode(['success' => true, 'message' => 'Signed out successfully']);
}

function handleGetReviews($supabase, $data) {
    $appId = $data['appId'] ?? '';
    $token = $data['token'] ?? null;
    
    if (empty($appId)) {
        echo json_encode(['success' => false, 'error' => 'App ID is required']);
        exit();
    }
    
    $reviews = $supabase->getReviews($appId, $token);
    
    echo json_encode([
        'success' => true,
        'reviews' => $reviews
    ]);
}

function handleSubmitReview($supabase, $data) {
    $appId = $data['appId'] ?? '';
    $userId = $data['userId'] ?? '';
    $username = $data['username'] ?? '';
    $rating = $data['rating'] ?? 0;
    $comment = $data['comment'] ?? '';
    $token = $data['token'] ?? null;
    
    // Validate required fields
    if (empty($appId) || empty($userId) || empty($username) || empty($rating)) {
        echo json_encode(['success' => false, 'error' => 'App ID, User ID, Username, and Rating are required']);
        exit();
    }
    
    // Validate rating
    $rating = (int)$rating;
    if ($rating < 1 || $rating > 5) {
        echo json_encode(['success' => false, 'error' => 'Rating must be between 1 and 5']);
        exit();
    }
    
    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'Authentication token is required']);
        exit();
    }
    
    $response = $supabase->submitReview($appId, $userId, $username, $rating, $comment, $token);
    
    if ($response['success']) {
        echo json_encode(['success' => true, 'message' => 'Review submitted successfully']);
    } else {
        $error = 'Failed to submit review';
        if (isset($response['data']['message'])) {
            $error = $response['data']['message'];
        } elseif (isset($response['data']['error'])) {
            $error = $response['data']['error'];
        }
        
        // Check if it's an auth error
        if ($response['code'] === 401 || $response['code'] === 403) {
            $error = 'Authentication failed. Please log in again.';
        }
        
        echo json_encode(['success' => false, 'error' => $error]);
    }
}

function handleDeleteReview($supabase, $data) {
    $reviewId = $data['reviewId'] ?? 0;
    $token = $data['token'] ?? null;
    
    if (empty($reviewId)) {
        echo json_encode(['success' => false, 'error' => 'Review ID is required']);
        exit();
    }
    
    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'Authentication token is required']);
        exit();
    }
    
    $response = $supabase->deleteReview($reviewId, $token);
    
    if ($response['success']) {
        echo json_encode(['success' => true, 'message' => 'Review deleted successfully']);
    } else {
        $error = 'Failed to delete review';
        if (isset($response['data']['message'])) {
            $error = $response['data']['message'];
        }
        
        echo json_encode(['success' => false, 'error' => $error]);
    }
}

function handleGetUserReviews($supabase, $data) {
    $userId = $data['userId'] ?? '';
    $token = $data['token'] ?? null;
    
    if (empty($userId)) {
        echo json_encode(['success' => false, 'error' => 'User ID is required']);
        exit();
    }
    
    $reviews = $supabase->getUserReviews($userId, $token);
    
    echo json_encode([
        'success' => true,
        'reviews' => $reviews
    ]);
}

function handleGetReview($supabase, $data) {
    $reviewId = $data['reviewId'] ?? 0;
    $token = $data['token'] ?? null;
    
    if (empty($reviewId)) {
        echo json_encode(['success' => false, 'error' => 'Review ID is required']);
        exit();
    }
    
    $review = $supabase->getReviewById($reviewId, $token);
    
    if ($review) {
        echo json_encode([
            'success' => true,
            'review' => $review
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Review not found'
        ]);
    }
}

function handleValidateToken($supabase, $data) {
    $token = $data['token'] ?? null;
    
    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'Token is required']);
        exit();
    }
    
    $response = $supabase->validateToken($token);
    
    if ($response['success']) {
        $userData = $response['data'] ?? [];
        
        echo json_encode([
            'success' => true,
            'user' => [
                'id' => $userData['id'] ?? '',
                'email' => $userData['email'] ?? ''
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid token']);
    }
}
?>