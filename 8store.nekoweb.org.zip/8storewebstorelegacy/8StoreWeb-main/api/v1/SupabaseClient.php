<?php
class SupabaseClient {
    private $supabaseUrl;
    private $supabaseKey;
    
    public function __construct() {
        $this->supabaseUrl = SUPABASE_URL;
        $this->supabaseKey = SUPABASE_KEY;
    }
    
    /**
     * Make HTTP request using file_get_contents
     */
    public function request($method, $endpoint, $data = null, $token = null) {
        $url = $this->supabaseUrl . $endpoint;
        
        $headers = [
            'apikey: ' . $this->supabaseKey,
            'Content-Type: application/json',
            'Prefer: return=representation'
        ];
        
        if ($token) {
            $headers[] = 'Authorization: Bearer ' . $token;
        }
        
        $options = [
            'http' => [
                'method'  => $method,
                'header'  => implode("\r\n", $headers),
                'timeout' => 30,
                'ignore_errors' => true
            ]
        ];
        
        if ($data) {
            $options['http']['content'] = json_encode($data);
        }
        
        // Disable SSL verification for Windows 8.1
        if (strpos($url, 'https://') === 0) {
            $options['ssl'] = [
                'verify_peer' => false,
                'verify_peer_name' => false
            ];
        }
        
        $context = stream_context_create($options);
        
        try {
            $response = file_get_contents($url, false, $context);
            
            // Get HTTP status code
            $statusLine = $http_response_header[0] ?? '';
            preg_match('/HTTP\/\d\.\d\s+(\d+)/', $statusLine, $matches);
            $httpCode = isset($matches[1]) ? (int)$matches[1] : 500;
            
            $parsedResponse = null;
            if ($response !== false) {
                $parsedResponse = json_decode($response, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log("JSON decode error: " . json_last_error_msg());
                    $parsedResponse = ['raw' => $response];
                }
            }
            
            return [
                'success' => ($httpCode >= 200 && $httpCode < 300),
                'code' => $httpCode,
                'data' => $parsedResponse
            ];
            
        } catch (Exception $e) {
            error_log("HTTP request error: " . $e->getMessage());
            return [
                'success' => false,
                'code' => 0,
                'data' => ['error' => $e->getMessage()]
            ];
        }
    }

    public function getAllAppsReviewStats() {
    // Use a Supabase RPC function if you have one, or direct query
        $response = $this->request('GET', 
            '/rest/v1/reviews?select=app_id,rating', 
            null, 
            null
        );
    
        return $response;
    }
    
    /**
     * Sign up a new user
     */
    public function signUp($email, $password, $username) {
        if (strlen($password) < 6) {
            return [
                'success' => false,
                'error' => 'Password must be at least 6 characters'
            ];
        }
        
        $response = $this->request('POST', '/auth/v1/signup', [
            'email' => $email,
            'password' => $password,
            'data' => ['username' => $username]
        ]);
        
        return $response;
    }
    
    /**
     * Sign in existing user
     */
    public function signIn($email, $password) {
        $response = $this->request('POST', '/auth/v1/token?grant_type=password', [
            'email' => $email,
            'password' => $password
        ]);
        
        return $response;
    }
    
    /**
     * Get user profile
     */
    public function getUserProfile($userId, $token) {
        $response = $this->request('GET', '/rest/v1/profiles?id=eq.' . urlencode($userId), null, $token);
        
        if ($response['success'] && is_array($response['data']) && count($response['data']) > 0) {
            return $response['data'][0];
        }
        
        return null;
    }
    
    /**
     * Create user profile
     */
    public function createProfile($userId, $email, $username, $token) {
        $response = $this->request('POST', '/rest/v1/profiles', [
            [
                'id' => $userId,
                'email' => $email,
                'username' => $username,
                'created_at' => date('c')
            ]
        ], $token);
        
        return $response;
    }
    
    /**
     * Get reviews for an app
     */
    public function getReviews($appId, $token = null) {
        $response = $this->request('GET', '/rest/v1/reviews?app_id=eq.' . urlencode($appId) . '&order=created_at.desc', null, $token);
        
        if ($response['success']) {
            return $response['data'] ?: [];
        }
        
        return [];
    }
    
    /**
     * Submit a review
     */
    public function submitReview($appId, $userId, $username, $rating, $comment, $token) {
        // Check if review already exists
        $checkResponse = $this->request('GET', 
            '/rest/v1/reviews?app_id=eq.' . urlencode($appId) . '&user_id=eq.' . urlencode($userId), 
            null, 
            $token
        );
        
        if ($checkResponse['success'] && is_array($checkResponse['data']) && count($checkResponse['data']) > 0) {
            // Update existing review
            $reviewId = $checkResponse['data'][0]['id'];
            $response = $this->request('PATCH', '/rest/v1/reviews?id=eq.' . $reviewId, [
                'rating' => (int)$rating,
                'comment' => $comment,
                'updated_at' => date('c')
            ], $token);
        } else {
            // Create new review
            $response = $this->request('POST', '/rest/v1/reviews', [
                [
                    'app_id' => $appId,
                    'user_id' => $userId,
                    'username' => $username,
                    'rating' => (int)$rating,
                    'comment' => $comment,
                    'created_at' => date('c')
                ]
            ], $token);
        }
        
        return $response;
    }
    
    /**
     * Delete a review
     */
    public function deleteReview($reviewId, $token) {
        $response = $this->request('DELETE', '/rest/v1/reviews?id=eq.' . $reviewId, null, $token);
        return $response;
    }
    
    /**
     * Get single review by ID
     */
    public function getReviewById($reviewId, $token = null) {
        $response = $this->request('GET', '/rest/v1/reviews?id=eq.' . $reviewId, null, $token);
        
        if ($response['success'] && is_array($response['data']) && count($response['data']) > 0) {
            return $response['data'][0];
        }
        
        return null;
    }
    
    /**
     * Get user's reviews
     */
    public function getUserReviews($userId, $token = null) {
        $response = $this->request('GET', '/rest/v1/reviews?user_id=eq.' . urlencode($userId) . '&order=created_at.desc', null, $token);
        
        if ($response['success']) {
            return $response['data'] ?: [];
        }
        
        return [];
    }
    
    /**
     * Validate JWT token
     */
    public function validateToken($token) {
        $response = $this->request('GET', '/auth/v1/user', null, $token);
        return $response;
    }
}
?>