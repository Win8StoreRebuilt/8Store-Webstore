<?php
// Configuration
define('SUPABASE_URL', 'https://fsnjkoteftrzjtlwzuat.supabase.co');
define('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZzbmprb3RlZnRyemp0bHd6dWF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcxNTM0MTEsImV4cCI6MjA4MjcyOTQxMX0.jHxNakyN7yR-YawbQbbv0omcVbwc1b_oolbOP_YGYEk');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/error.log');

// Create logs directory
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}
?>