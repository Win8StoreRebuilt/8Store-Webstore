<?php
require_once 'config.php';

class AuthHelper {
    
    /**
     * Validate email format
     */
    public static function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Validate username (alphanumeric + underscores, 3-20 chars)
     */
    public static function isValidUsername($username) {
        return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
    }
    
    /**
     * Sanitize input
     */
    public static function sanitize($input) {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize'], $input);
        }
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Generate API response
     */
    public static function jsonResponse($success, $data = [], $error = null, $statusCode = 200) {
        http_response_code($statusCode);
        
        $response = [
            'success' => $success,
            'timestamp' => date('c'),
            'version' => API_VERSION
        ];
        
        if ($success) {
            $response['data'] = $data;
        } else {
            $response['error'] = $error;
        }
        
        // Add debug info in development
        if (ini_get('display_errors')) {
            $response['debug'] = [
                'server_time' => date('Y-m-d H:i:s'),
                'memory_usage' => memory_get_usage(true)
            ];
        }
        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
    
    /**
     * Log API activity
     */
    public static function logActivity($action, $data = []) {
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'action' => $action,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'data' => $data
        ];
        
        $logFile = __DIR__ . '/logs/activity.log';
        file_put_contents($logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}
?>