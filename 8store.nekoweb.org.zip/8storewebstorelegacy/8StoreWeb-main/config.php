<?php
// Configuration
define('JSON_DIR', dirname(__FILE__) . '/data/');
define('APPS_FILE', JSON_DIR . 'apps.json');
define('PENDING_FILE', JSON_DIR . 'pending.json');
define('USERS_FILE', JSON_DIR . 'users.json');

// Default admin credentials (change these!)
$default_admin = [
    'username' => 'TrendyPokolomia',
    'password' => 'DJAADKDRU09120429DADS', // Change this!
    'name' => '#omg'
];

// Create data directory if it doesn't exist
if (!file_exists(JSON_DIR)) {
    mkdir(JSON_DIR, 0755, true);
}

// Create users file with default admin if it doesn't exist
if (!file_exists(USERS_FILE)) {
    file_put_contents(USERS_FILE, json_encode([$default_admin], JSON_PRETTY_PRINT));
}

// Create empty files if they don't exist
if (!file_exists(APPS_FILE)) {
    file_put_contents(APPS_FILE, '[]');
}

if (!file_exists(PENDING_FILE)) {
    file_put_contents(PENDING_FILE, '[]');
}

// Start session
session_start();
?>