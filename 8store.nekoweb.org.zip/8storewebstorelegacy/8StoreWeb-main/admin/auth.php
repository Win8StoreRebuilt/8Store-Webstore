<?php
require_once '../config.php';

header('Content-Type: application/json');

// Check if already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    echo json_encode(['success' => true, 'message' => 'Already logged in']);
    exit;
}

// Get POST data
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validate input
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Username and password are required']);
    exit;
}

// Read users file
$usersData = file_get_contents(USERS_FILE);
$users = json_decode($usersData, true);

if ($users === null) {
    echo json_encode(['success' => false, 'message' => 'User database error']);
    exit;
}

// Find user
$authenticated = false;
foreach ($users as $user) {
    if ($user['username'] === $username && $user['password'] === $password) {
        $authenticated = true;
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_name'] = $user['name'];
        break;
    }
}

if ($authenticated) {
    echo json_encode(['success' => true, 'message' => 'Login successful']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
}
?>