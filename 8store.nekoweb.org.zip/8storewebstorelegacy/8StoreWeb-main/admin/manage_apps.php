<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.html');
    exit;
}

// Read approved apps
$appsData = file_get_contents(APPS_FILE);
$apps = json_decode($appsData, true) ?: [];

// Search functionality
$searchQuery = $_GET['search'] ?? '';
$filteredApps = $apps;

if (!empty($searchQuery)) {
    $searchQuery = strtolower($searchQuery);
    $filteredApps = array_filter($apps, function($app) use ($searchQuery) {
        return (stripos($app['name'], $searchQuery) !== false) ||
               (stripos($app['publisher'], $searchQuery) !== false) ||
               (stripos($app['description'], $searchQuery) !== false) ||
               (stripos($app['id'], $searchQuery) !== false);
    });
}

// Sort apps by ID (newest first)
usort($filteredApps, function($a, $b) {
    return intval($b['id']) - intval($a['id']);
});

$totalApps = count($apps);
$filteredCount = count($filteredApps);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Apps - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .header {
            background: linear-gradient(135deg, #0067b8, #00a4ef);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logout-btn, .dashboard-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .logout-btn:hover, .dashboard-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .page-title {
            font-size: 1.8rem;
            color: #0067b8;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .search-box {
            display: flex;
            gap: 10px;
            max-width: 500px;
            flex: 1;
        }
        
        .search-input {
            flex: 1;
            padding: 10px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        .search-input:focus {
            border-color: #0067b8;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 103, 184, 0.1);
        }
        
        .search-btn {
            padding: 10px 20px;
            background-color: #0067b8;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }
        
        .search-btn:hover {
            background-color: #005a9e;
        }
        
        .stats-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stat-value {
            font-size: 1.3rem;
            font-weight: bold;
            color: #0067b8;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .clear-search-btn {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .clear-search-btn:hover {
            background-color: #5a6268;
        }
        
        .apps-table {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .table-header {
            display: grid;
            grid-template-columns: 50px 60px 2fr 1.5fr 1fr 100px 120px;
            background: #f8f9fa;
            padding: 15px 20px;
            border-bottom: 2px solid #eaeaea;
            font-weight: 600;
            color: #333;
        }
        
        .app-row {
            display: grid;
            grid-template-columns: 50px 60px 2fr 1.5fr 1fr 100px 120px;
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
            align-items: center;
        }
        
        .app-row:hover {
            background-color: #f8f9fa;
        }
        
        .app-row:last-child {
            border-bottom: none;
        }
        
        .app-icon-cell {
            display: flex;
            justify-content: center;
        }
        
        .table-app-icon {
            width: 40px;
            height: 40px;
            object-fit: contain;
            border-radius: 6px;
        }
        
        .app-id {
            font-weight: 600;
            color: #0067b8;
            font-size: 0.9rem;
        }
        
        .app-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 3px;
        }
        
        .app-description {
            color: #666;
            font-size: 0.85rem;
            line-height: 1.3;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .app-publisher, .app-version {
            color: #555;
            font-size: 0.9rem;
        }
        
        .featured-indicator {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #ffc107;
            color: #333;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .not-featured {
            color: #999;
            font-size: 0.85rem;
        }
        
        .download-link {
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #0067b8;
            text-decoration: none;
            font-size: 0.85rem;
        }
        
        .download-link:hover {
            text-decoration: underline;
        }
        
        .actions-cell {
            display: flex;
            gap: 8px;
        }
        
        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.85rem;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .btn-edit {
            background-color: #17a2b8;
            color: white;
        }
        
        .btn-edit:hover {
            background-color: #138496;
        }
        
        .btn-delete {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-delete:hover {
            background-color: #c82333;
        }
        
        .btn-test {
            background-color: #28a745;
            color: white;
        }
        
        .btn-test:hover {
            background-color: #218838;
        }
        
        .no-apps {
            padding: 60px 20px;
            text-align: center;
            color: #666;
            grid-column: 1 / -1;
        }
        
        @media (max-width: 1200px) {
            .table-header, .app-row {
                grid-template-columns: 40px 50px 2fr 1fr 80px 80px;
            }
            
            .app-version {
                display: none;
            }
        }
        
        @media (max-width: 992px) {
            .table-header, .app-row {
                grid-template-columns: 40px 1fr 1fr;
                padding: 15px;
            }
            
            .app-publisher, .app-version, .featured-cell, .download-cell {
                display: none;
            }
            
            .app-description {
                -webkit-line-clamp: 1;
            }
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .user-info {
                flex-direction: column;
                gap: 10px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                max-width: 100%;
            }
            
            .stats-bar {
                flex-direction: column;
                align-items: flex-start;
            }
        }
        
        @media (max-width: 576px) {
            .table-header, .app-row {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .app-icon-cell, .app-id-cell, .featured-cell, .download-cell, .actions-cell {
                display: none;
            }
            
            .app-name {
                font-size: 1rem;
            }
            
            .app-description {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><i class="fas fa-cog"></i> Manage Apps</h1>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
            <a href="dashboard.php" class="dashboard-btn">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <i class="fas fa-boxes"></i> Manage Approved Apps
            </div>
            <form method="GET" action="manage_apps.php" class="search-box">
                <input type="text" 
                       name="search" 
                       class="search-input" 
                       placeholder="Search by name, publisher, description, or ID..."
                       value="<?php echo htmlspecialchars($searchQuery); ?>">
                <button type="submit" class="search-btn">
                    <i class="fas fa-search"></i> Search
                </button>
            </form>
        </div>
        
        <div class="stats-bar">
            <div class="stat-item">
                <div class="stat-value"><?php echo $totalApps; ?></div>
                <div class="stat-label">Total Apps</div>
            </div>
            
            <?php if (!empty($searchQuery)): ?>
                <div class="stat-item">
                    <div class="stat-value"><?php echo $filteredCount; ?></div>
                    <div class="stat-label">Search Results</div>
                </div>
                <a href="manage_apps.php" class="clear-search-btn">
                    <i class="fas fa-times"></i> Clear Search
                </a>
            <?php else: ?>
                <div class="stat-item">
                    <div class="stat-value"><?php echo $totalApps; ?></div>
                    <div class="stat-label">Apps in Database</div>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="apps-table">
            <div class="table-header">
                <div class="app-icon-cell">Icon</div>
                <div>ID</div>
                <div>App Name & Description</div>
                <div>Publisher</div>
                <div>Version</div>
                <div>Featured</div>
                <div>Actions</div>
            </div>
            
            <?php if (empty($filteredApps)): ?>
                <div class="no-apps">
                    <i class="fas fa-search" style="font-size: 3rem; color: #6c757d; margin-bottom: 15px;"></i>
                    <h3>No apps found</h3>
                    <p><?php echo empty($searchQuery) ? 'No apps in the database yet.' : 'No apps match your search.'; ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($filteredApps as $app): ?>
                    <div class="app-row">
                        <div class="app-icon-cell">
                            <img src="<?php echo htmlspecialchars($app['iconUrl']); ?>" 
                                 alt="<?php echo htmlspecialchars($app['name']); ?>" 
                                 class="table-app-icon"
                                 onerror="this.src='https://icons.iconarchive.com/icons/dakirby309/windows-8-metro/256/Folders-OS-Windows-8-Metro-icon.png'">
                        </div>
                        <div class="app-id"><?php echo htmlspecialchars($app['id']); ?></div>
                        <div>
                            <div class="app-name"><?php echo htmlspecialchars($app['name']); ?></div>
                            <div class="app-description"><?php echo htmlspecialchars($app['description']); ?></div>
                            <div style="margin-top: 5px;">
                                <a href="<?php echo htmlspecialchars($app['downloadUrl']); ?>" 
                                   target="_blank" 
                                   class="download-link"
                                   title="<?php echo htmlspecialchars($app['downloadUrl']); ?>">
                                    <i class="fas fa-download"></i> Download Link
                                </a>
                            </div>
                        </div>
                        <div class="app-publisher"><?php echo htmlspecialchars($app['publisher']); ?></div>
                        <div class="app-version"><?php echo htmlspecialchars($app['version']); ?></div>
                        <div>
                            <?php if ($app['featured']): ?>
                                <span class="featured-indicator">
                                    <i class="fas fa-star"></i> Featured
                                </span>
                            <?php else: ?>
                                <span class="not-featured">No</span>
                            <?php endif; ?>
                        </div>
                        <div class="actions-cell">
                            <a href="edit_app.php?id=<?php echo $app['id']; ?>" class="btn btn-edit">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="<?php echo htmlspecialchars($app['downloadUrl']); ?>" 
                               target="_blank" 
                               class="btn btn-test">
                                <i class="fas fa-external-link-alt"></i> Test
                            </a>
                            <button class="btn btn-delete" onclick="deleteApp(<?php echo $app['id']; ?>, '<?php echo htmlspecialchars(addslashes($app['name'])); ?>')">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function deleteApp(appId, appName) {
            if (!confirm(`Are you sure you want to delete "${appName}" (ID: ${appId})? This action cannot be undone.`)) {
                return;
            }
            
            fetch('delete_app.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + appId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('App deleted successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Network error. Please try again.');
            });
        }
    </script>
</body>
</html>