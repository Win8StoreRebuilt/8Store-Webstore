<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

header('Content-Type: application/json');

// Get app ID from POST
$appId = $_POST['id'] ?? '';

if (empty($appId)) {
    echo json_encode(['success' => false, 'message' => 'App ID is required']);
    exit;
}

// Debug logging
error_log("Deleting app with ID: $appId");

// Read approved apps
$appsData = file_get_contents(APPS_FILE);
if ($appsData === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to read apps file']);
    exit;
}

$apps = json_decode($appsData, true);
if ($apps === null) {
    $apps = [];
}

error_log("Total apps before deletion: " . count($apps));

// Find and remove the app
$found = false;
$newApps = [];

foreach ($apps as $app) {
    if ($app['id'] == $appId) {
        $found = true;
        error_log("Found app to delete: " . $app['name'] . " (ID: " . $app['id'] . ")");
        continue; // Skip this app (delete it)
    }
    $newApps[] = $app;
}

if (!$found) {
    error_log("App not found: $appId");
    echo json_encode(['success' => false, 'message' => 'App not found']);
    exit;
}

error_log("Total apps after deletion: " . count($newApps));

// Save updated apps list
$result = file_put_contents(APPS_FILE, json_encode($newApps, JSON_PRETTY_PRINT));
if ($result === false) {
    error_log("Failed to write to apps file");
    echo json_encode(['success' => false, 'message' => 'Failed to delete app']);
    exit;
}

error_log("App deleted successfully: $appId");
echo json_encode([
    'success' => true,
    'message' => 'App deleted successfully'
]);
?>