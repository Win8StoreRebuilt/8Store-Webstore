<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

header('Content-Type: application/json');

// Get index from POST
$index = $_POST['index'] ?? null;

if ($index === null || !is_numeric($index)) {
    echo json_encode(['success' => false, 'message' => 'Invalid submission index']);
    exit;
}

// Read pending submissions
$pendingData = file_get_contents(PENDING_FILE);
$pending = json_decode($pendingData, true);

if (!isset($pending[$index])) {
    echo json_encode(['success' => false, 'message' => 'Submission not found']);
    exit;
}

// Remove from pending
array_splice($pending, $index, 1);

// Save pending submissions
if (file_put_contents(PENDING_FILE, json_encode($pending, JSON_PRETTY_PRINT)) === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to update pending submissions']);
    exit;
}

echo json_encode([
    'success' => true,
    'message' => 'App rejected successfully'
]);
?>