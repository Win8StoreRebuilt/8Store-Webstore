<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.html');
    exit;
}

// Read pending submissions
$pendingData = file_get_contents(PENDING_FILE);
$pending = json_decode($pendingData, true) ?: [];

// Read approved apps
$appsData = file_get_contents(APPS_FILE);
$apps = json_decode($appsData, true) ?: [];

// Search functionality for approved apps
$searchQuery = $_GET['search'] ?? '';
$searchFilteredApps = $apps;

if (!empty($searchQuery)) {
    $searchQuery = strtolower($searchQuery);
    $searchFilteredApps = array_filter($apps, function($app) use ($searchQuery) {
        return (stripos($app['name'], $searchQuery) !== false) ||
               (stripos($app['publisher'], $searchQuery) !== false) ||
               (stripos($app['description'], $searchQuery) !== false) ||
               (stripos($app['id'], $searchQuery) !== false);
    });
}

// Sort apps by ID (newest first)
usort($searchFilteredApps, function($a, $b) {
    return intval($b['id']) - intval($a['id']);
});

// Get stats
$pendingCount = count($pending);
$approvedCount = count($apps);
$searchCount = count($searchFilteredApps);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - 8Store Portal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@200;300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'Segoe UI Extra Light', 'Segoe UI Light', 'Segoe UI Semilight', Tahoma, Geneva, Verdana, sans-serif;
            font-weight: 200;
        }
        
        body {
            background-color: #1a1a1a;
            color: #ffffff;
            min-height: 100vh;
            background-image: url('https://learn-attachment.microsoft.com/api/attachments/94fda143-a475-4529-8957-8d1aba911f4b?platform=QnA');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            background-blend-mode: overlay;
            background-color: rgba(0, 0, 0, 0.85);
        }
        
        .metro-grid-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(to right, rgba(0, 120, 215, 0.05) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(0, 120, 215, 0.05) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: -1;
            pointer-events: none;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 25px 30px;
            margin-bottom: 30px;
            border: 1px solid #0078d7;
            border-left: 6px solid #0078d7;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header h1 {
            font-size: 2.2rem;
            font-weight: 300;
            display: flex;
            align-items: center;
            gap: 15px;
            color: #0078d7;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .welcome-text {
            color: #a0a0a0;
            font-size: 1.1rem;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 0;
            font-size: 1rem;
            font-weight: 400;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            min-width: 120px;
            justify-content: center;
        }
        
        .btn-primary {
            background-color: #0078d7;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #005a9e;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background-color: #767676;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #5d5d5d;
            transform: translateY(-2px);
        }
        
        .btn-logout {
            background-color: #e81123;
            color: white;
        }
        
        .btn-logout:hover {
            background-color: #c50f1f;
            transform: translateY(-2px);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .stat-tile {
            background: rgba(40, 40, 40, 0.9);
            padding: 30px;
            border: 1px solid #444;
            border-left: 6px solid #0078d7;
            transition: all 0.3s ease;
        }
        
        .stat-tile:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            border-color: #0078d7;
        }
        
        .stat-value {
            font-size: 3rem;
            font-weight: 300;
            color: #0078d7;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 1rem;
            color: #a0a0a0;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .section-title {
            font-size: 1.8rem;
            font-weight: 300;
            color: #ffffff;
            margin: 40px 0 20px 0;
            padding-bottom: 15px;
            border-bottom: 2px solid #0078d7;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .search-container {
            background: rgba(40, 40, 40, 0.9);
            padding: 25px;
            border: 1px solid #444;
            margin-bottom: 30px;
        }
        
        .search-box {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .search-input {
            flex: 1;
            min-width: 300px;
            padding: 14px 20px;
            border: 2px solid #555;
            background: #1a1a1a;
            color: white;
            font-size: 1rem;
            font-weight: 300;
            border-radius: 0;
        }
        
        .search-input:focus {
            border-color: #0078d7;
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 120, 215, 0.3);
        }
        
        .search-info {
            background: rgba(0, 120, 215, 0.1);
            padding: 20px;
            border: 1px solid #0078d7;
            margin: 20px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .search-stats {
            font-size: 1.1rem;
            color: #a0a0a0;
        }
        
        .search-stats strong {
            color: #0078d7;
            font-weight: 400;
        }
        
        .apps-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .app-tile {
            background: rgba(40, 40, 40, 0.9);
            border: 1px solid #444;
            padding: 25px;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .app-tile:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            border-color: #0078d7;
        }
        
        .app-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .app-icon {
            width: 60px;
            height: 60px;
            object-fit: contain;
            border: 1px solid #555;
        }
        
        .app-title {
            flex: 1;
        }
        
        .app-name {
            font-size: 1.4rem;
            font-weight: 300;
            color: #ffffff;
            margin-bottom: 5px;
        }
        
        .app-publisher {
            font-size: 1rem;
            color: #a0a0a0;
        }
        
        .app-description {
            color: #d0d0d0;
            font-size: 1rem;
            line-height: 1.6;
            margin-bottom: 20px;
            min-height: 60px;
        }
        
        .app-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #444;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #a0a0a0;
            font-size: 0.9rem;
        }
        
        .meta-item i {
            color: #0078d7;
        }
        
        .app-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 8px 16px;
            border: 1px solid;
            background: transparent;
            color: white;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }
        
        .btn-approve {
            border-color: #00bc6a;
            color: #00bc6a;
        }
        
        .btn-approve:hover {
            background-color: #00bc6a;
            color: white;
        }
        
        .btn-reject {
            border-color: #e81123;
            color: #e81123;
        }
        
        .btn-reject:hover {
            background-color: #e81123;
            color: white;
        }
        
        .btn-edit {
            border-color: #ffb900;
            color: #ffb900;
        }
        
        .btn-edit:hover {
            background-color: #ffb900;
            color: #000;
        }
        
        .btn-test {
            border-color: #0078d7;
            color: #0078d7;
        }
        
        .btn-test:hover {
            background-color: #0078d7;
            color: white;
        }
        
        .btn-delete {
            border-color: #e81123;
            color: #e81123;
        }
        
        .btn-delete:hover {
            background-color: #e81123;
            color: white;
        }
        
        .featured-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: #ffb900;
            color: #000;
            padding: 4px 12px;
            font-size: 0.8rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .alert {
            padding: 20px;
            margin-bottom: 30px;
            border: 1px solid;
            display: none;
        }
        
        .alert-success {
            background-color: rgba(0, 188, 106, 0.1);
            color: #00bc6a;
            border-color: #00bc6a;
            border-left: 6px solid #00bc6a;
        }
        
        .no-items {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: #a0a0a0;
        }
        
        .no-items i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #0078d7;
        }
        
        .no-items h3 {
            font-size: 1.8rem;
            font-weight: 300;
            margin-bottom: 10px;
            color: #ffffff;
        }
        
        .download-url {
            background: rgba(0, 120, 215, 0.1);
            border: 1px solid #0078d7;
            padding: 12px;
            margin-top: 15px;
            font-size: 0.85rem;
            color: #a0a0a0;
            word-break: break-all;
            font-family: monospace;
        }
        
        .url-label {
            color: #0078d7;
            font-size: 0.9rem;
            margin-bottom: 5px;
            display: block;
        }
        
        .pending-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: #0078d7;
            color: white;
            padding: 4px 12px;
            font-size: 0.8rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .user-info {
                justify-content: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .apps-list {
                grid-template-columns: 1fr;
            }
            
            .search-box {
                flex-direction: column;
            }
            
            .search-input {
                min-width: 100%;
            }
        }
        
        /* Metro Accent Colors */
        .accent-blue { color: #0078d7; }
        .accent-green { color: #00bc6a; }
        .accent-red { color: #e81123; }
        .accent-yellow { color: #ffb900; }
        .accent-purple { color: #b146c2; }
    </style>
</head>
<body>
    <!-- Metro Grid Background -->
    <div class="metro-grid-bg"></div>
    
    <div class="container">
        <div class="header">
            <h1><i class="fab fa-windows accent-blue"></i> 8Store Admin Dashboard</h1>
            <div class="user-info">
                <span class="welcome-text">Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                <?php if (file_exists('manage_apps.php')): ?>
                    <a href="manage_apps.php" class="btn btn-primary">
                        <i class="fas fa-cog"></i> Manage Apps
                    </a>
                <?php endif; ?>
                <a href="logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
        
        <div id="successAlert" class="alert alert-success">
            <i class="fas fa-check-circle accent-green"></i> <span id="successMessage"></span>
        </div>
        
        <div class="stats-grid">
            <div class="stat-tile">
                <div class="stat-value"><?php echo $pendingCount; ?></div>
                <div class="stat-label">Pending Submissions</div>
            </div>
            <div class="stat-tile">
                <div class="stat-value"><?php echo $approvedCount; ?></div>
                <div class="stat-label">Approved Apps</div>
            </div>
            <div class="stat-tile">
                <div class="stat-value"><?php echo $approvedCount + $pendingCount; ?></div>
                <div class="stat-label">Total Submissions</div>
            </div>
        </div>
        
        <h2 class="section-title">
            <i class="fas fa-clock accent-blue"></i> Pending Submissions
        </h2>
        
        <div class="apps-list">
            <?php if (empty($pending)): ?>
                <div class="no-items">
                    <i class="fas fa-check-circle"></i>
                    <h3>No pending submissions</h3>
                    <p>All submissions have been reviewed.</p>
                </div>
            <?php else: ?>
                <?php foreach ($pending as $index => $submission): ?>
                    <div class="app-tile" id="submission-<?php echo $index; ?>">
                        <span class="pending-badge"><i class="fas fa-clock"></i> Pending</span>
                        <div class="app-header">
                            <img src="<?php echo htmlspecialchars($submission['iconUrl']); ?>" 
                                 alt="<?php echo htmlspecialchars($submission['name']); ?>" 
                                 class="app-icon"
                                 onerror="this.src='https://icons.iconarchive.com/icons/dakirby309/windows-8-metro/256/Folders-OS-Windows-8-Metro-icon.png'">
                            <div class="app-title">
                                <div class="app-name"><?php echo htmlspecialchars($submission['name']); ?></div>
                                <div class="app-publisher"><?php echo htmlspecialchars($submission['publisher']); ?></div>
                            </div>
                        </div>
                        
                        <div class="app-description"><?php echo htmlspecialchars($submission['description']); ?></div>
                        
                        <div class="app-meta">
                            <div class="meta-item">
                                <i class="fas fa-code-branch"></i>
                                <span>Version: <?php echo htmlspecialchars($submission['version']); ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-calendar"></i>
                                <span><?php echo htmlspecialchars($submission['submitted_at']); ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-hashtag"></i>
                                <span>Temp ID: <?php echo htmlspecialchars($submission['tempId']); ?></span>
                            </div>
                        </div>
                        
                        <div class="url-label">Download URL:</div>
                        <div class="download-url" title="<?php echo htmlspecialchars($submission['downloadUrl']); ?>">
                            <?php echo htmlspecialchars($submission['downloadUrl']); ?>
                        </div>
                        
                        <div class="app-actions">
                            <button class="action-btn btn-approve" onclick="approveApp(<?php echo $index; ?>)">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="action-btn btn-reject" onclick="rejectApp(<?php echo $index; ?>)">
                                <i class="fas fa-times"></i> Reject
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <h2 class="section-title" style="margin-top: 60px;">
            <i class="fas fa-list accent-blue"></i> Approved Apps
        </h2>
        
        <!-- Search Bar for Approved Apps -->
        <div class="search-container">
            <form method="GET" action="dashboard.php" class="search-box">
                <input type="text" 
                       name="search" 
                       class="search-input" 
                       placeholder="Search approved apps by name, publisher, description, or ID..."
                       value="<?php echo htmlspecialchars($searchQuery); ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Search
                </button>
                <?php if (!empty($searchQuery)): ?>
                    <a href="dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                <?php endif; ?>
            </form>
        </div>
        
        <?php if (!empty($searchQuery)): ?>
            <div class="search-info">
                <div class="search-stats">
                    <div>
                        <strong><?php echo $searchCount; ?></strong> app<?php echo $searchCount != 1 ? 's' : ''; ?> found
                    </div>
                    <div>
                        Searching for: <strong>"<?php echo htmlspecialchars($searchQuery); ?>"</strong>
                    </div>
                </div>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Clear Search
                </a>
            </div>
        <?php endif; ?>
        
        <div class="apps-list">
            <?php if (empty($searchFilteredApps)): ?>
                <div class="no-items">
                    <?php if (!empty($searchQuery)): ?>
                        <i class="fas fa-search"></i>
                        <h3>No apps found</h3>
                        <p>No apps match your search for "<?php echo htmlspecialchars($searchQuery); ?>".</p>
                    <?php else: ?>
                        <i class="fas fa-box-open"></i>
                        <h3>No approved apps yet</h3>
                        <p>Approved apps will appear here.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php 
                // Limit to 12 results if not searching
                $displayApps = $searchFilteredApps;
                if (empty($searchQuery)) {
                    $displayApps = array_slice($searchFilteredApps, 0, 12);
                }
                
                foreach ($displayApps as $index => $app): ?>
                    <div class="app-tile">
                        <?php if ($app['featured']): ?>
                            <span class="featured-badge"><i class="fas fa-star"></i> Featured</span>
                        <?php endif; ?>
                        
                        <div class="app-header">
                            <img src="<?php echo htmlspecialchars($app['iconUrl']); ?>" 
                                 alt="<?php echo htmlspecialchars($app['name']); ?>" 
                                 class="app-icon"
                                 onerror="this.src='https://icons.iconarchive.com/icons/dakirby309/windows-8-metro/256/Folders-OS-Windows-8-Metro-icon.png'">
                            <div class="app-title">
                                <div class="app-name"><?php echo htmlspecialchars($app['name']); ?></div>
                                <div class="app-publisher"><?php echo htmlspecialchars($app['publisher']); ?></div>
                            </div>
                        </div>
                        
                        <div class="app-description"><?php echo htmlspecialchars($app['description']); ?></div>
                        
                        <div class="app-meta">
                            <div class="meta-item">
                                <i class="fas fa-code-branch"></i>
                                <span>Version: <?php echo htmlspecialchars($app['version']); ?></span>
                            </div>
                            <div class="meta-item">
                                <i class="fas fa-hashtag"></i>
                                <span>ID: <?php echo htmlspecialchars($app['id']); ?></span>
                            </div>
                        </div>
                        
                        <div class="url-label">Download URL:</div>
                        <div class="download-url" title="<?php echo htmlspecialchars($app['downloadUrl']); ?>">
                            <?php echo htmlspecialchars($app['downloadUrl']); ?>
                        </div>
                        
                        <div class="app-actions">
                            <a href="edit_app.php?id=<?php echo $app['id']; ?>" class="action-btn btn-edit">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="<?php echo htmlspecialchars($app['downloadUrl']); ?>" 
                               target="_blank" 
                               class="action-btn btn-test"
                               title="Test download link">
                                <i class="fas fa-external-link-alt"></i> Test
                            </a>
                            <button class="action-btn btn-delete" onclick="deleteApp(<?php echo $app['id']; ?>, '<?php echo htmlspecialchars(addslashes($app['name'])); ?>')">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <?php if (empty($searchQuery) && count($searchFilteredApps) > 12): ?>
                    <div class="app-tile" style="grid-column: 1 / -1; text-align: center; background: rgba(0, 120, 215, 0.1);">
                        <div style="padding: 30px;">
                            <i class="fas fa-info-circle accent-blue" style="font-size: 2rem; margin-bottom: 15px;"></i>
                            <h3 style="color: #ffffff; margin-bottom: 10px;">Showing 12 of <?php echo count($searchFilteredApps); ?> approved apps</h3>
                            <?php if (file_exists('manage_apps.php')): ?>
                                <a href="manage_apps.php" class="btn btn-primary" style="margin-top: 15px;">
                                    <i class="fas fa-external-link-alt"></i> View All Apps
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function showSuccess(message) {
            const alert = document.getElementById('successAlert');
            const messageSpan = document.getElementById('successMessage');
            messageSpan.textContent = message;
            alert.style.display = 'block';
            
            // Hide after 5 seconds
            setTimeout(() => {
                alert.style.display = 'none';
            }, 5000);
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        function approveApp(index) {
            if (!confirm('Are you sure you want to approve this app?')) {
                return;
            }
            
            fetch('approve.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=approve&index=' + index
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove from pending list
                    const item = document.getElementById('submission-' + index);
                    if (item) {
                        item.style.opacity = '0.5';
                        item.style.transform = 'scale(0.95)';
                        setTimeout(() => {
                            item.remove();
                            showSuccess('App approved successfully! New ID: ' + data.newId);
                            // Reload page after 2 seconds to update stats
                            setTimeout(() => {
                                location.reload();
                            }, 2000);
                        }, 500);
                    }
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Network error. Please try again.');
            });
        }
        
        function rejectApp(index) {
            if (!confirm('Are you sure you want to reject this app?')) {
                return;
            }
            
            fetch('reject.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=reject&index=' + index
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove from pending list
                    const item = document.getElementById('submission-' + index);
                    if (item) {
                        item.style.opacity = '0.5';
                        item.style.transform = 'scale(0.95)';
                        setTimeout(() => {
                            item.remove();
                            showSuccess('App rejected successfully.');
                            // Reload page after 2 seconds to update stats
                            setTimeout(() => {
                                location.reload();
                            }, 2000);
                        }, 500);
                    }
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Network error. Please try again.');
            });
        }
        
        function deleteApp(appId, appName) {
            if (!confirm(`Are you sure you want to delete "${appName}" (ID: ${appId})? This action cannot be undone.`)) {
                return;
            }
            
            fetch('delete_app.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + appId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('App deleted successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Network error. Please try again.');
            });
        }
        
        // Check for success message in URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('approved')) {
            showSuccess('App approved successfully!');
        }
    </script>
</body>
</html>