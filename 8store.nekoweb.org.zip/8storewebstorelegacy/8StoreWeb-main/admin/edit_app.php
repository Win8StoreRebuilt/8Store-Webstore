<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.html');
    exit;
}

// Get app ID from URL
$appId = $_GET['id'] ?? '';

if (empty($appId)) {
    header('Location: manage_apps.php');
    exit;
}

// Read approved apps
$appsData = file_get_contents(APPS_FILE);
$apps = json_decode($appsData, true) ?: [];

// Find the app by ID
$appToEdit = null;
$appIndex = null;

foreach ($apps as $index => $app) {
    if ($app['id'] == $appId) {
        $appToEdit = $app;
        $appIndex = $index;
        break;
    }
}

if ($appToEdit === null) {
    header('Location: manage_apps.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get updated data
    $updatedApp = [
        'id' => $appId,
        'name' => $_POST['name'] ?? $appToEdit['name'],
        'publisher' => $_POST['publisher'] ?? $appToEdit['publisher'],
        'version' => $_POST['version'] ?? $appToEdit['version'],
        'description' => $_POST['description'] ?? $appToEdit['description'],
        'downloadUrl' => $_POST['downloadUrl'] ?? $appToEdit['downloadUrl'],
        'iconUrl' => $_POST['iconUrl'] ?? $appToEdit['iconUrl'],
        'featured' => isset($_POST['featured']) ? true : false
    ];
    
    // Validate download URL
    if (!preg_match('/\.appx(bundle)?$/i', $updatedApp['downloadUrl'])) {
        $error = 'Download URL must end with .appx or .appxbundle';
    } else {
        // Update the app in the array
        $apps[$appIndex] = $updatedApp;
        
        // Save to file
        if (file_put_contents(APPS_FILE, json_encode($apps, JSON_PRETTY_PRINT)) !== false) {
            $success = 'App updated successfully!';
            $appToEdit = $updatedApp; // Update displayed data
        } else {
            $error = 'Failed to save changes';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit App - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .header {
            background: linear-gradient(135deg, #0067b8, #00a4ef);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logout-btn, .back-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .logout-btn:hover, .back-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .page-title {
            font-size: 1.8rem;
            color: #0067b8;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .app-id-badge {
            background-color: #0067b8;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .edit-form {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #444;
        }
        
        .required {
            color: #dc3545;
        }
        
        input[type="text"],
        input[type="url"],
        textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        input[type="text"]:focus,
        input[type="url"]:focus,
        textarea:focus {
            border-color: #0067b8;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 103, 184, 0.1);
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        input[type="checkbox"] {
            width: 18px;
            height: 18px;
        }
        
        .url-validation {
            margin-top: 5px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
            min-height: 20px;
        }
        
        .valid {
            color: #28a745;
        }
        
        .invalid {
            color: #dc3545;
        }
        
        .preview-section {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #eee;
        }
        
        .preview-title {
            font-size: 1.2rem;
            color: #0067b8;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .app-preview {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #eaeaea;
        }
        
        .preview-icon {
            width: 60px;
            height: 60px;
            object-fit: contain;
            border-radius: 8px;
        }
        
        .preview-info h3 {
            color: #333;
            margin-bottom: 5px;
        }
        
        .preview-description {
            color: #666;
            font-size: 0.9rem;
        }
        
        .buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }
        
        .btn-primary {
            background-color: #0067b8;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #005a9e;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .user-info {
                flex-direction: column;
                gap: 10px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><i class="fas fa-edit"></i> Edit App</h1>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
            <a href="manage_apps.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Apps
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="container">
        <div class="page-header">
            <div class="page-title">
                <i class="fas fa-edit"></i> Edit App Details
            </div>
            <div class="app-id-badge">
                <i class="fas fa-hashtag"></i> ID: <?php echo htmlspecialchars($appId); ?>
            </div>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" class="edit-form">
            <div class="form-group">
                <label for="name">App Name <span class="required">*</span></label>
                <input type="text" id="name" name="name" 
                       value="<?php echo htmlspecialchars($appToEdit['name']); ?>" 
                       placeholder="e.g., Microsoft Office" required>
            </div>
            
            <div class="form-group">
                <label for="publisher">Publisher <span class="required">*</span></label>
                <input type="text" id="publisher" name="publisher" 
                       value="<?php echo htmlspecialchars($appToEdit['publisher']); ?>" 
                       placeholder="e.g., Microsoft Corporation" required>
            </div>
            
            <div class="form-group">
                <label for="version">Version <span class="required">*</span></label>
                <input type="text" id="version" name="version" 
                       value="<?php echo htmlspecialchars($appToEdit['version']); ?>" 
                       placeholder="e.g., 1.0.0.0" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" 
                          placeholder="Short description of the app"><?php echo htmlspecialchars($appToEdit['description']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="downloadUrl">Download URL <span class="required">*</span></label>
                <input type="url" id="downloadUrl" name="downloadUrl" 
                       value="<?php echo htmlspecialchars($appToEdit['downloadUrl']); ?>" 
                       placeholder="https://example.com/app.appx" required>
                <div id="urlValidation" class="url-validation">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>URL must end with .appx or .appxbundle</span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="iconUrl">Icon URL</label>
                <input type="url" id="iconUrl" name="iconUrl" 
                       value="<?php echo htmlspecialchars($appToEdit['iconUrl']); ?>" 
                       placeholder="https://example.com/icon.png">
                <small style="color: #666; display: block; margin-top: 5px;">If empty, a default icon will be used</small>
            </div>
            
            <div class="form-group">
                <div class="checkbox-group">
                    <input type="checkbox" id="featured" name="featured" 
                           <?php echo $appToEdit['featured'] ? 'checked' : ''; ?>>
                    <label for="featured">Featured App</label>
                </div>
                <small style="color: #666; display: block; margin-top: 5px;">Featured apps appear in a special section on the main page</small>
            </div>
            
            <div class="preview-section">
                <div class="preview-title">
                    <i class="fas fa-eye"></i> Live Preview
                </div>
                <div class="app-preview">
                    <img id="previewIcon" 
                         src="<?php echo htmlspecialchars($appToEdit['iconUrl']); ?>" 
                         alt="App Icon" 
                         class="preview-icon"
                         onerror="this.src='https://icons.iconarchive.com/icons/dakirby309/windows-8-metro/256/Folders-OS-Windows-8-Metro-icon.png'">
                    <div class="preview-info">
                        <h3 id="previewName"><?php echo htmlspecialchars($appToEdit['name']); ?></h3>
                        <div class="preview-description" id="previewDescription">
                            <?php echo htmlspecialchars($appToEdit['description']); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="buttons">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Changes
                </button>
                <a href="manage_apps.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancel
                </a>
                <button type="button" class="btn btn-danger" onclick="deleteApp(<?php echo $appId; ?>, '<?php echo htmlspecialchars(addslashes($appToEdit['name'])); ?>')">
                    <i class="fas fa-trash"></i> Delete App
                </button>
            </div>
        </form>
    </div>
    
    <script>
        // Live preview update
        const nameInput = document.getElementById('name');
        const descriptionInput = document.getElementById('description');
        const iconInput = document.getElementById('iconUrl');
        const previewName = document.getElementById('previewName');
        const previewDescription = document.getElementById('previewDescription');
        const previewIcon = document.getElementById('previewIcon');
        
        nameInput.addEventListener('input', function() {
            previewName.textContent = this.value || 'App Name';
        });
        
        descriptionInput.addEventListener('input', function() {
            previewDescription.textContent = this.value || 'App description';
        });
        
        iconInput.addEventListener('input', function() {
            previewIcon.src = this.value || 'https://icons.iconarchive.com/icons/dakirby309/windows-8-metro/256/Folders-OS-Windows-8-Metro-icon.png';
        });
        
        // URL validation
        const downloadUrlInput = document.getElementById('downloadUrl');
        const urlValidation = document.getElementById('urlValidation');
        
        downloadUrlInput.addEventListener('input', function() {
            validateUrl(this.value);
        });
        
        function validateUrl(url) {
            const validExtensions = ['.appx', '.appxbundle'];
            const isValid = validExtensions.some(ext => url.toLowerCase().endsWith(ext));
            
            if (url === '') {
                urlValidation.className = 'url-validation';
                urlValidation.innerHTML = '<i class="fas fa-exclamation-circle"></i><span>URL must end with .appx or .appxbundle</span>';
                return false;
            } else if (isValid) {
                urlValidation.className = 'url-validation valid';
                urlValidation.innerHTML = '<i class="fas fa-check-circle"></i><span>URL has a valid extension</span>';
                return true;
            } else {
                urlValidation.className = 'url-validation invalid';
                urlValidation.innerHTML = '<i class="fas fa-times-circle"></i><span>URL must end with .appx or .appxbundle</span>';
                return false;
            }
        }
        
        // Initialize validation
        validateUrl(downloadUrlInput.value);
        
        function deleteApp(appId, appName) {
            if (!confirm(`Are you sure you want to delete "${appName}" (ID: ${appId})? This action cannot be undone.`)) {
                return;
            }
            
            fetch('delete_app.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + appId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('App deleted successfully! Redirecting to app list...');
                    window.location.href = 'manage_apps.php';
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Network error. Please try again.');
            });
        }
    </script>
</body>
</html>