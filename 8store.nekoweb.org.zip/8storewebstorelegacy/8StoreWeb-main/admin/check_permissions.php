<?php
// check_permissions.php
echo "<h1>Permission Check</h1>";

// Check data directory
$dataDir = 'data/';
echo "<h2>Data Directory: $dataDir</h2>";
echo "Exists: " . (file_exists($dataDir) ? 'Yes' : 'No') . "<br>";
echo "Is writable: " . (is_writable($dataDir) ? 'Yes' : 'No') . "<br>";

// Check apps.json
$appsFile = $dataDir . 'apps.json';
echo "<h2>Apps File: $appsFile</h2>";
echo "Exists: " . (file_exists($appsFile) ? 'Yes' : 'No') . "<br>";
echo "Is writable: " . (is_writable($appsFile) ? 'Yes' : 'No') . "<br>";

// Check pending.json
$pendingFile = $dataDir . 'pending.json';
echo "<h2>Pending File: $pendingFile</h2>";
echo "Exists: " . (file_exists($pendingFile) ? 'Yes' : 'No') . "<br>";
echo "Is writable: " . (is_writable($pendingFile) ? 'Yes' : 'No') . "<br>";

// Check current directory
echo "<h2>Current Directory</h2>";
echo "Path: " . getcwd() . "<br>";
echo "Is writable: " . (is_writable('.')) ? 'Yes' : 'No';

// Test write
echo "<h2>Test Write</h2>";
$testFile = $dataDir . 'test.txt';
if (file_put_contents($testFile, 'Test content')) {
    echo "Write successful<br>";
    if (unlink($testFile)) {
        echo "Delete successful";
    } else {
        echo "Delete failed";
    }
} else {
    echo "Write failed";
}
?>