<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

header('Content-Type: application/json');

// Get index from POST
$index = $_POST['index'] ?? null;

if ($index === null || !is_numeric($index)) {
    echo json_encode(['success' => false, 'message' => 'Invalid submission index']);
    exit;
}

// Read pending submissions
$pendingData = file_get_contents(PENDING_FILE);
$pending = json_decode($pendingData, true);

if (!isset($pending[$index])) {
    echo json_encode(['success' => false, 'message' => 'Submission not found']);
    exit;
}

// Get the submission
$submission = $pending[$index];

// Read approved apps
$appsData = file_get_contents(APPS_FILE);
$apps = json_decode($appsData, true) ?: [];

// Find the highest ID
$maxId = 0;
foreach ($apps as $app) {
    $id = intval($app['id']);
    if ($id > $maxId) {
        $maxId = $id;
    }
}

// New ID is maxId + 1
$newId = $maxId + 1;

// Create new app object
$newApp = [
    'id' => (string)$newId,
    'name' => $submission['name'],
    'publisher' => $submission['publisher'],
    'version' => $submission['version'],
    'description' => $submission['description'],
    'downloadUrl' => $submission['downloadUrl'],
    'iconUrl' => $submission['iconUrl'],
    'featured' => false
];

// Add to approved apps
$apps[] = $newApp;

// Remove from pending
array_splice($pending, $index, 1);

// Save both files
if (file_put_contents(APPS_FILE, json_encode($apps, JSON_PRETTY_PRINT)) === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to save approved apps']);
    exit;
}

if (file_put_contents(PENDING_FILE, json_encode($pending, JSON_PRETTY_PRINT)) === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to update pending submissions']);
    exit;
}

echo json_encode([
    'success' => true,
    'message' => 'App approved successfully',
    'newId' => $newId
]);
?>