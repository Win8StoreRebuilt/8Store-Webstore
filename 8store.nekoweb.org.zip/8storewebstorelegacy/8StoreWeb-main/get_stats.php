<?php
require_once 'config.php';

header('Content-Type: application/json');

// Read approved apps
$appsData = file_get_contents(APPS_FILE);
$apps = json_decode($appsData, true);
$approvedCount = is_array($apps) ? count($apps) : 0;

// Read pending submissions
$pendingData = file_get_contents(PENDING_FILE);
$pending = json_decode($pendingData, true);
$pendingCount = is_array($pending) ? count($pending) : 0;

echo json_encode([
    'success' => true,
    'approved' => $approvedCount,
    'pending' => $pendingCount
]);
?>