const API_BASE = "https://8store.dankassassin368.com/";

/* Throttle to stay under 300 requests/min */
let lastRequestTime = 0;
const MIN_DELAY = 250;

async function throttledFetch(url, options = {}) {
  const now = Date.now();
  const wait = Math.max(0, MIN_DELAY - (now - lastRequestTime));
  if (wait) await new Promise(r => setTimeout(r, wait));
  lastRequestTime = Date.now();
  return fetch(url, options);
}

/* Helpers */
function iconUrl(app) {
  return app.iconUrl || "img/placeholder.png";
}

function screenshotUrls(app) {
  const urls = [];
  for (let i = 1; i <= 10; i++) {
    const key = `screenshot${i}`;
    if (app[key]) urls.push(app[key]);
  }
  return urls;
}

/* Normalize backend app objects */
function normalizeApp(app) {
  let id = app.id;

  const hex32 = /^[0-9a-f]{32}$/i;
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  if (typeof id === "string") {
    if (!uuid.test(id) && hex32.test(id)) {
      id = id.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, "$1-$2-$3-$4-$5");
    } else if (!uuid.test(id)) {
      id = crypto.randomUUID();
    }
  } else {
    id = crypto.randomUUID();
  }

  const normalized = {
    id,
    name: app.name,
    publisher: app.publisher,
    category: app.category,
    description: app.description,

    iconUrl: app.icon_path
      ? `${API_BASE}/api/files/${id}/${app.icon_path}`
      : "img/placeholder.png",

    downloadUrl: app.file_path
      ? `${API_BASE}/api/files/${id}/${app.file_path}`
      : null
  };

  // SAFE screenshot parsing
  let rawShots = app.screenshots;
  let shots = [];

  try {
    if (Array.isArray(rawShots)) {
      shots = rawShots;
    } else if (typeof rawShots === "string" && rawShots.trim() !== "") {
      const parsed = JSON.parse(rawShots);
      if (Array.isArray(parsed)) shots = parsed;
    }
  } catch {
    shots = [];
  }

  if (!Array.isArray(shots)) shots = [];

  shots.forEach((s, i) => {
    normalized[`screenshot${i + 1}`] = `${API_BASE}/api/files/${id}/${s}`;
  });

  return normalized;
}

/* Alphabetical sorting */
function sortAppsAZ(apps) {
  return apps.slice().sort((a, b) => a.name.localeCompare(b.name));
}

/* Paginated all apps */
async function fetchAppsBatch(start, end) {
  try {
    const url = `${API_BASE}/api/applications?start=${start}&end=${end}`;
    const res = await throttledFetch(url);
    const data = await res.json();
    return (data.applications || []).map(normalizeApp);
  } catch (e) {
    console.error("Failed to load apps:", e);
    return [];
  }
}

/* Paginated search */
async function searchAppsBatch(query, start, end) {
  try {
    const url = `${API_BASE}/api/applications/search?query=${encodeURIComponent(query)}&start=${start}&end=${end}`;
    const res = await throttledFetch(url);
    const data = await res.json();
    if (data.success === false) return [];
    return (data.applications || []).map(normalizeApp);
  } catch (e) {
    console.error("Search failed:", e);
    return [];
  }
}

/* NEW: Category listing */
async function fetchCategoryBatch(category, start, end) {
  try {
    const url = `${API_BASE}/api/applications/category/${encodeURIComponent(category)}?start=${start}&end=${end}`;
    const res = await throttledFetch(url);
    const data = await res.json();
    return (data.applications || []).map(normalizeApp);
  } catch (e) {
    console.error("Category load failed:", e);
    return [];
  }
}

/* NEW: Category search */
async function searchCategoryBatch(category, query, start, end) {
  try {
    const url = `${API_BASE}/api/applications/category/${encodeURIComponent(category)}/search?query=${encodeURIComponent(query)}&start=${start}&end=${end}`;
    const res = await throttledFetch(url);
    const data = await res.json();
    return (data.applications || []).map(normalizeApp);
  } catch (e) {
    console.error("Category search failed:", e);
    return [];
  }
}

/* RESTORED: Legacy full list (needed for category list only) */
async function fetchLegacyAllApps() {
  try {
    const res = await throttledFetch(`${API_BASE}/api/legacy/applications`);
    const data = await res.json();
    const list = Array.isArray(data) ? data : data.applications || [];
    return list.map(normalizeApp);
  } catch (e) {
    console.error("Failed to load legacy apps:", e);
    return [];
  }
}

/* Reviews */
async function fetchReviews(appId) {
  try {
    const url = `${API_BASE}/api/applications/reviews/${appId}/?start=0&end=50`;
    const res = await throttledFetch(url);
    const data = await res.json();
    return data.reviews || [];
  } catch (e) {
    console.error("Reviews failed:", e);
    return [];
  }
}

async function postReview(appId, reviewText) {
  try {
    const url = `${API_BASE}/api/applications/reviews/${appId}/post`;
    const res = await throttledFetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ review: reviewText })
    });
    return await res.json();
  } catch (e) {
    console.error("Post review failed:", e);
    return { success: false, error: "network_error" };
  }
}
