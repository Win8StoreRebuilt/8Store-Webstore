document.addEventListener("DOMContentLoaded", () => {

  const homeView = document.getElementById("homeView");
  const homeGrid = document.getElementById("homeGrid");

  const searchView = document.getElementById("searchView");
  const searchGrid = document.getElementById("searchGrid");
  const searchBack = document.getElementById("searchBack");
  const searchBox = document.getElementById("searchBox");

  const detailView = document.getElementById("detailView");

  const sidebar = document.getElementById("sidebar");
  const sidebarContent = document.getElementById("sidebarContent");
  const hamburger = document.getElementById("hamburger");
  const main = document.getElementById("main");

  const loadMoreHome = document.getElementById("loadMoreHome");
  const loadMoreSearch = document.getElementById("loadMoreSearch");

  let homeStart = 0;
  let searchStart = 0;
  let categoryStart = 0;

  const BATCH = 50;

  let currentSearchQuery = "";
  let currentCategory = null;

  /* Sidebar open/close */
  function closeSidebar() {
    sidebar.classList.remove("open");
    main.classList.remove("shifted");
  }

  hamburger.addEventListener("click", () => {
    const open = sidebar.classList.toggle("open");
    if (open) main.classList.add("shifted");
    else main.classList.remove("shifted");
  });

  document.addEventListener("click", (e) => {
    if (!sidebar.contains(e.target) && e.target !== hamburger) {
      closeSidebar();
    }
  });

  /* Tile builder */
  function createTile(app) {
    const tile = document.createElement("div");
    tile.className = "tile";

    const icon = iconUrl(app);

    tile.innerHTML = `
      <img src="${icon}" class="tile-icon" onerror="this.src='img/placeholder.png'">
      <span>${app.name}</span>
      <span>${app.publisher || ""}</span>
    `;

    tile.addEventListener("click", () => openDetail(app));
    return tile;
  }

  /* Categories from legacy list */
  function loadCategories(apps) {
    const categories = [...new Set(apps.map(a => a.category).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b));

    sidebarContent.innerHTML = `
      <button class="category-btn" data-category="all">
        <span>All Apps</span>
        <span class="category-count">${apps.length}</span>
      </button>
      ${categories.map(c => {
        const count = apps.filter(a => a.category === c).length;
        return `
          <button class="category-btn" data-category="${c}">
            <span>${c}</span>
            <span class="category-count">${count}</span>
          </button>
        `;
      }).join("")}
    `;

    document.querySelectorAll(".category-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const cat = btn.dataset.category;
        if (cat === "all") {
          currentCategory = null;
          loadHome(true);
        } else {
          currentCategory = cat;
          loadCategory(cat, true);
        }
        closeSidebar();
      });
    });
  }

  /* Category loader using new API */
  async function loadCategory(category, reset = false) {
    if (reset) categoryStart = 0;

    if (categoryStart === 0) {
      homeGrid.querySelectorAll(".tile").forEach(t => t.remove());
      loadMoreHome.classList.add("hidden");
    }

    const apps = await fetchCategoryBatch(category, categoryStart, categoryStart + BATCH);

    apps.forEach(app => homeGrid.insertBefore(createTile(app), loadMoreHome));

    categoryStart += BATCH;

    if (apps.length < BATCH) loadMoreHome.classList.add("hidden");
    else loadMoreHome.classList.remove("hidden");

    document.querySelector(".section-title").textContent = category;

    homeView.classList.remove("hidden");
    searchView.classList.add("hidden");
    detailView.classList.add("hidden");
  }

  /* HOME — PAGINATED */
  async function loadHome(reset = false) {
    currentCategory = null;

    if (reset) homeStart = 0;

    if (homeStart === 0) {
      homeGrid.querySelectorAll(".tile").forEach(t => t.remove());
      loadMoreHome.classList.add("hidden");
    }

    const apps = await fetchAppsBatch(homeStart, homeStart + BATCH);

    apps.forEach(app => homeGrid.insertBefore(createTile(app), loadMoreHome));

    homeStart += BATCH;

    if (apps.length < BATCH) loadMoreHome.classList.add("hidden");
    else loadMoreHome.classList.remove("hidden");

    document.querySelector(".section-title").textContent = "All apps";

    homeView.classList.remove("hidden");
    searchView.classList.add("hidden");
    detailView.classList.add("hidden");
  }

  loadMoreHome.addEventListener("click", () => {
    if (currentCategory) loadCategory(currentCategory, false);
    else loadHome(false);
  });

  /* SEARCH — supports category search */
  async function renderSearch(query, reset = true) {
    if (!query) return;

    if (reset) {
      searchStart = 0;
      currentSearchQuery = query;
      searchGrid.querySelectorAll(".tile").forEach(t => t.remove());
      loadMoreSearch.classList.add("hidden");
    }

    let apps;

    if (currentCategory) {
      apps = await searchCategoryBatch(currentCategory, query, searchStart, searchStart + BATCH);
    } else {
      apps = await searchAppsBatch(query, searchStart, searchStart + BATCH);
    }

    apps.forEach(app => searchGrid.insertBefore(createTile(app), loadMoreSearch));

    searchStart += BATCH;

    if (apps.length < BATCH) loadMoreSearch.classList.add("hidden");
    else loadMoreSearch.classList.remove("hidden");

    searchView.classList.remove("hidden");
    homeView.classList.add("hidden");
    detailView.classList.add("hidden");
  }

  loadMoreSearch.addEventListener("click", () => {
    renderSearch(currentSearchQuery, false);
  });

  searchBox.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      renderSearch(e.target.value.trim(), true);
    }
  });

  searchBack.addEventListener("click", () => {
    searchView.classList.add("hidden");
    homeView.classList.remove("hidden");
  });

  /* DETAIL */
  async function openDetail(app) {
    detailView.innerHTML = "Loading…";

    const icon = iconUrl(app);
    const screenshots = screenshotUrls(app);

    detailView.innerHTML = `
      <button class="back-button" id="detailBack">← Back</button>

      <img src="${icon}" class="detail-icon-large">

      <h2>${app.name}</h2>
      <p>${app.publisher || ""}</p>
      <p>${app.category || ""}</p>

      ${
        app.downloadUrl
          ? `<a href="${app.downloadUrl}" class="download-btn" download>Download</a>`
          : ""
      }

      <p>${app.description || ""}</p>

      <div class="detail-screenshots">
        ${screenshots.map(s => `<img src="${s}" class="detail-screenshot">`).join("")}
      </div>

      <div id="reviewsContainer"></div>
    `;

    document.getElementById("detailBack").addEventListener("click", () => {
      detailView.classList.add("hidden");
      homeView.classList.remove("hidden");
    });

    const reviewsContainer = document.getElementById("reviewsContainer");
    await renderReviews(app.id, reviewsContainer);

    detailView.classList.remove("hidden");
    homeView.classList.add("hidden");
    searchView.classList.add("hidden");
  }

  /* INITIAL LOAD */
  loadHome(true);

  /* Load categories from legacy list */
  fetchLegacyAllApps().then(apps => {
    window._allApps = apps;
    loadCategories(apps);
  });
});
