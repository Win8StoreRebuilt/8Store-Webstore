/* ============================
   Reviews API + UI Rendering
   ============================ */

/* GET reviews using the NEW endpoint */
async function fetchReviews(appId) {
  try {
    // Example: /api/applications/reviews/5e0b752e-54a8-4b1b-8d26-588eaeb480ab/
    const url = `${API_BASE}/api/inapp/applications/reviews/${appId}`;
    const res = await throttledFetch(url);
    const data = await res.json();
    return data.reviews || [];
  } catch (e) {
    console.error("Reviews failed:", e);
    return [];
  }
}

/* POST a new review using the NEW endpoint */
async function postReview(appId, reviewText) {
  try {
    // Example: /api/applications/reviews/5e0b752e-54a8-4b1b-8d26-588eaeb480ab/post
    const url = `${API_BASE}/api/applications/reviews/${appId}/post`;
    const res = await throttledFetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      credentials: "include",
      body: JSON.stringify({ review: reviewText })
    });
    return await res.json();
  } catch (e) {
    console.error("Post review failed:", e);
    return { success: false, error: "network_error" };
  }
}

/* Render reviews + form */
async function renderReviews(appId, container) {
  const reviews = await fetchReviews(appId);

  container.innerHTML = `
    <h3>Reviews</h3>
    <ul>
      ${
        reviews.length
          ? reviews
              .map(
                r =>
                  `<li><strong>${r.author?.name || "Anonymous"}:</strong> ${r.review}</li>`
              )
              .join("")
          : "<li>No reviews yet.</li>"
      }
    </ul>
    <div id="reviewForm">
      <textarea id="reviewInput" rows="3" placeholder="Write a review..."></textarea>
      <button id="reviewSubmit">Post review</button>
      <div id="reviewLoginHint"></div>
    </div>
  `;

  const reviewInput = document.getElementById("reviewInput");
  const reviewSubmit = document.getElementById("reviewSubmit");
  const reviewLoginHint = document.getElementById("reviewLoginHint");

  /* Disable form if not logged in */
  if (!authState.loggedIn) {
    if (reviewInput) reviewInput.disabled = true;
    if (reviewSubmit) reviewSubmit.disabled = true;
    if (reviewLoginHint)
      reviewLoginHint.textContent = "Log in with Discord to post a review.";
    return;
  }

  if (reviewLoginHint) reviewLoginHint.textContent = "";

  /* Submit handler */
  if (reviewSubmit && reviewInput) {
    reviewSubmit.addEventListener("click", async () => {
      const text = reviewInput.value.trim();
      if (!text) return;

      const result = await postReview(appId, text);
      if (result.success) {
        reviewInput.value = "";
        await renderReviews(appId, container); // reload list
      } else {
        console.error("Failed to post review:", result);
        alert("Failed to post review.");
      }
    });
  }
}
