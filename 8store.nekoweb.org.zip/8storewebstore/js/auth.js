// ===============================
// 8Store Webstore OAuth (NEW API)
// ===============================

// OAuth must START on backend domain
// and RETURN to the new webstore root
const AUTH_START_URL =
  "https://8store.dankassassin368.com/api/auth/discord" +
  "?return_to=" +
  encodeURIComponent("https://8storewebstore.dankassassin368.com/");

const authState = {
  loggedIn: false,
  user: null
};

function updateAuthUI() {
  const loginBtn = document.getElementById("loginButton");
  const profileName = document.getElementById("profileName");
  const profileAvatar = document.getElementById("profileAvatar");

  if (!loginBtn) return;

  if (authState.loggedIn) {
    loginBtn.textContent = "Log out";

    if (profileName) profileName.textContent = authState.user?.name || "Discord user";
    if (profileAvatar) profileAvatar.src = authState.user?.avatarUrl || "img/profile-placeholder.png";
  } else {
    loginBtn.textContent = "Log in with Discord";
    if (profileName) profileName.textContent = "Not logged in";
    if (profileAvatar) profileAvatar.src = "img/profile-placeholder.png";
  }
}

// ===============================
// Fetch logged-in user
// ===============================

async function loadUser() {
  try {
    const res = await fetch("https://8store.dankassassin368.com/api/auth/me", {
      credentials: "include"
    });

    if (!res.ok) {
      authState.loggedIn = false;
      authState.user = null;
      updateAuthUI();
      return;
    }

    const data = await res.json();

    if (data.authenticated && data.user) {
      authState.loggedIn = true;
      authState.user = {
        name: data.user.globalName || data.user.username,
        avatarUrl: data.user.avatar
          ? `https://cdn.discordapp.com/avatars/${data.user.id}/${data.user.avatar}.png`
          : "img/profile-placeholder.png"
      };
    } else {
      authState.loggedIn = false;
      authState.user = null;
    }

    updateAuthUI();
  } catch (err) {
    console.error("Failed to load user:", err);
  }
}

// ===============================
// Logout
// ===============================

async function logout() {
  try {
    await fetch("https://8store.dankassassin368.com/api/auth/logout", {
      method: "POST",
      credentials: "include"
    });
  } catch (e) {
    console.error("Logout error:", e);
  }

  authState.loggedIn = false;
  authState.user = null;
  updateAuthUI();
}

// ===============================
// Init
// ===============================

function initAuth() {
  loadUser();

  const loginBtn = document.getElementById("loginButton");
  if (!loginBtn) return;

  loginBtn.addEventListener("click", async () => {
    if (!authState.loggedIn) {
      try {
        const res = await fetch(AUTH_START_URL, {
          credentials: "include"
        });
        const data = await res.json();

        if (data.url) {
          window.location.href = data.url; // redirect to Discord OAuth
        } else {
          console.error("OAuth start failed:", data);
        }
      } catch (err) {
        console.error("OAuth start error:", err);
      }
    } else {
      logout();
    }
  });
}

document.addEventListener("DOMContentLoaded", initAuth);
